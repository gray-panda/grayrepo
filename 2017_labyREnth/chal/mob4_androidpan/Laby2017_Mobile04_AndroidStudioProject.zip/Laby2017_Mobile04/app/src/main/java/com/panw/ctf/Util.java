package com.panw.ctf;

/**
 * Created by ggg on 28/6/17.
 */

public class Util {
    public static native boolean isFlagCorrect(String flag);

    public static String getFlagHash(String filename){
        return "3;:j>99j2??38=9n3o:i?:;9>><<9<28i>>j>;hoi<>;om>=2njiiojm9hi:;23=";
    }
}
