package com.panw.ctf;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.AsyncTask;
import android.os.PowerManager;
import android.support.v4.content.LocalBroadcastManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import static android.icu.lang.UCharacter.GraphemeClusterBreak.T;

public class MainActivity extends AppCompatActivity {
    Intent mSvcIntent;
    PowerManager.WakeLock wakelock;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        System.loadLibrary("checker");

        Button bruteBtn = (Button) findViewById(R.id.btnBrute);
        bruteBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBtnClick(view);
            }
        });

        IntentFilter statusFilter = new IntentFilter(MyConstants.BROADCAST_ACTION);
        ResultReceiver rcver = new ResultReceiver();
        LocalBroadcastManager.getInstance(this).registerReceiver(rcver, statusFilter);

        PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
        wakelock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "MyWakeLockTag");
        wakelock.acquire();
    }

    protected void onBtnClick(View view){
        //boolean res = Util.isFlagCorrect("PAN{A00aAa!}");
        boolean res = Util.isFlagCorrect("PAN{L00tEr!}");
    }

    private class ResultReceiver extends BroadcastReceiver{
        private ResultReceiver(){}

        public void onReceive(Context context, Intent intent){
            Bundle bundle = intent.getExtras();
            String flag = bundle.getString(MyConstants.EXTENDED_DATA_STATUS);
            TextView output = (TextView) findViewById(R.id.txtMsg);
            output.setText(flag);
            //System.out.println("Flag Found: "+flag);
            //wakelock.release();
        }
    }
}
