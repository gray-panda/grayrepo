package com.panw.ctf;

import android.app.IntentService;
import android.content.Intent;
import android.content.Context;
import android.support.v4.content.LocalBroadcastManager;
import android.util.Log;

/**
 * An {@link IntentService} subclass for handling asynchronous task requests in
 * a service on a separate handler thread.
 * <p>
 * TODO: Customize class - update intent actions, extra parameters and static
 * helper methods.
 */
public class MyIntentService extends IntentService {

    public MyIntentService() {
        super("MyIntentService");
    }

    @Override
    protected void onHandleIntent(Intent intent) {
        // Do work here
        int count = 0;
        String flag = "";
        boolean found = false;
        for (int c1 = (int)'A'; c1 <= (int) 'A'; c1++){
            for (int c2 = (int) '0'; c2 <= (int) '9'; c2++){
                for (int c3 = (int) '0'; c3 <= (int) '9'; c3++){
                    for (int c4 = (int) 'a'; c4 <= (int) 'z'; c4++){
                        for (int c5 = (int) 'A'; c5 <= (int) 'Z'; c5++){
                            for (int c6 = (int) 'a'; c6 <= (int) 'z'; c6++){
                                for (int c7 = (int) '!'; c7 <= (int) '/'; c7++){
                                    flag = "PAN{" + (char) c1 + (char) c2 + (char) c3 + (char) c4 + (char) c5 + (char) c6 + (char) c7 + "}";
                                    count++;
                                    if (count % 10000 == 0){
                                        System.out.println(flag);
                                        //Intent localIntent = new Intent(MyConstants.BROADCAST_ACTION).putExtra(MyConstants.EXTENDED_DATA_STATUS, flag);
                                        //LocalBroadcastManager.getInstance(this).sendBroadcast(localIntent);
                                    }

                                    boolean res = Util.isFlagCorrect(flag);
                                    if (res == true){
                                        found = true;
                                        flag = "Found Flag: "+flag;
                                        System.out.println(flag);
                                        Intent localIntent = new Intent(MyConstants.BROADCAST_ACTION).putExtra(MyConstants.EXTENDED_DATA_STATUS, flag);
                                        LocalBroadcastManager.getInstance(this).sendBroadcast(localIntent);
                                    }
                                    if (found)break;
                                }
                                if (found)break;
                            }
                            if (found)break;
                        }
                        if (found)break;
                    }
                    if (found)break;
                }
                if (found)break;
            }
            if (found)break;
        }
    }
}
