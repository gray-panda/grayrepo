package com.panw.ctf;

/**
 * Created by ggg on 29/6/17.
 */

public final class MyConstants {
    public static String BROADCAST_ACTION = "com.panw.ctf.BROADCAST";
    public static String EXTENDED_DATA_STATUS = "com.panw.ctf.STATUS";
}
